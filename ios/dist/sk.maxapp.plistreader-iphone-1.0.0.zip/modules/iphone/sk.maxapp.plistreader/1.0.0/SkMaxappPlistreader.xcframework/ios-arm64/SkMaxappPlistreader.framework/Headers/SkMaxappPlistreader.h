//
//  SkMaxappPlistreader.h
//  test
//
//  Created by Marian Kucharcik
//  Copyright (c) 2022 Your Company. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SkMaxappPlistreader.
FOUNDATION_EXPORT double SkMaxappPlistreaderVersionNumber;

//! Project version string for SkMaxappPlistreader.
FOUNDATION_EXPORT const unsigned char SkMaxappPlistreaderVersionString[];

#import "SkMaxappPlistreaderModuleAssets.h"
